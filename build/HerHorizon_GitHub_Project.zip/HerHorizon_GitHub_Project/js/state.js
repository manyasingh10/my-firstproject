const APP_STATE = {
      calculatorVal: '0',
      keySequence: '',
      stealthPasscode: '98.6+=',
      coords: { lat: 19.250904, lng: 73.142782, acc: 25 },
      hasLiveGPS: false,
      gpsWatchId: null,
      selectedCorridor: 'safe',
      isSimulating: false,
      simStep: 0,
      simInterval: null,
      isSirenOn: false,
      audioContext: null,
      sirenOsc: null,
      map: null,
      userMarker: null,
      accuracyCircle: null,
      corridorLayers: { safe: null, direct: null },
      shelterMarkersGroup: null,
      guardMarkersGroup: null,
      activeShelterId: 1,
      currentShelterScope: 'available',
      currentFilterTag: 'all',
      shelters: [
        {
          id: 1,
          name: "Emergency Refugee Sanctuary",
          area: "Central Dadar",
          address: "Central Transit Corridor • 24/7 Priority Intake",
          beds: 5,
          familyUnits: 3,
          secType: "Armed Kiosk & CCTV",
          isFarther: false,
          dLat: 0.0032,
          dLng: -0.0016,
          tags: ["women", "kids", "accessible"]
        },
        {
          id: 2,
          name: "Sakha Protect Haven",
          area: "Colaba",
          address: "Maritime Safe Enclave Sector 4 • 24/7 Intake",
          beds: 2,
          familyUnits: 1,
          secType: "Verified CCTV & Escort",
          isFarther: false,
          dLat: 0.0018,
          dLng: 0.0045,
          tags: ["women", "pets", "accessible"]
        },
        {
          id: 3,
          name: "St. Jude Sanctuary Point",
          area: "Transit Riverline",
          address: "Transit Riverline Station • 24/7 Intake",
          beds: 9,
          familyUnits: 4,
          secType: "Perimeter Patrol Guard",
          isFarther: false,
          dLat: 0.0055,
          dLng: -0.0028,
          tags: ["women", "kids", "pets", "accessible"]
        },
        {
          id: 4,
          name: "Sakhi One-Stop Support Shelter",
          area: "Precinct Sector 3",
          address: "Municipal Safe Precinct Sector 3",
          beds: 0,
          familyUnits: 0,
          secType: "24/7 Monitored Safe Node",
          isFarther: false,
          dLat: -0.0042,
          dLng: 0.0062,
          tags: ["women", "accessible"]
        },
        {
          id: 5,
          name: "Harbor Sanctuary Point (Farther)",
          area: "Northern Coast Reach",
          address: "Outer Perimeter Highway Safe Station",
          beds: 14,
          familyUnits: 6,
          secType: "Armed Perimeter Security",
          isFarther: true,
          dLat: 0.0310,
          dLng: 0.0240,
          tags: ["women", "kids", "pets", "accessible"]
        },
        {
          id: 6,
          name: "West Highland Family Refuge (Farther)",
          area: "Western Foothills",
          address: "Regional Safe Sanctuary Sector 9",
          beds: 8,
          familyUnits: 5,
          secType: "24/7 State Police Node",
          isFarther: true,
          dLat: -0.0280,
          dLng: -0.0310,
          tags: ["women", "kids", "accessible"]
        }
      ]
    };

    if (localStorage.getItem('herhorizon_stealth_code')) {
      APP_STATE.stealthPasscode = localStorage.getItem('herhorizon_stealth_code');
    }

