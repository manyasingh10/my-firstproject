function renderAdminMatrix() {
      const tbody = document.getElementById('adminMatrixBody');
      if (!tbody) return;

      tbody.innerHTML = APP_STATE.shelters.map(s => {
        let statusClass = 'open';
        let statusText = 'Immediate Openings';
        if (s.beds === 0) {
          statusClass = 'full';
          statusText = 'At Capacity - Auto Rerouting Active';
        } else if (s.beds <= 2) {
          statusClass = 'limited';
          statusText = 'Limited Capacity';
        }

        return `
          <tr>
            <td>
              <strong>${s.name}</strong>
              <div style="font-size:11.5px;color:var(--text-muted);">${s.computedDist || '1.1 km'} away • ${s.area}</div>
            </td>
            <td>
              <span style="font-size:12px;font-weight:700;color:${s.isFarther ? '#9333ea' : '#1e40af'};">
                ${s.isFarther ? 'Farther Haven' : 'Nearby Haven'}
              </span>
            </td>
            <td>
              <div class="stepper-control">
                <button class="step-btn" onclick="adjustAdminCapacity(${s.id}, 'beds', -1)">−</button>
                <span class="step-val" id="admBed_${s.id}">${s.beds}</span>
                <button class="step-btn" onclick="adjustAdminCapacity(${s.id}, 'beds', 1)">+</button>
              </div>
            </td>
            <td>
              <div class="stepper-control">
                <button class="step-btn" onclick="adjustAdminCapacity(${s.id}, 'familyUnits', -1)">−</button>
                <span class="step-val" id="admFam_${s.id}">${s.familyUnits}</span>
                <button class="step-btn" onclick="adjustAdminCapacity(${s.id}, 'familyUnits', 1)">+</button>
              </div>
            </td>
            <td>
              <span class="status-tag ${statusClass}">${statusText}</span>
            </td>
            <td>
              ${s.isFarther ? `
                <button class="btn-act primary" style="padding:4px 9px;font-size:11.5px;" onclick="dispatchFartherShelterRide('${s.name}')">
                  🚗 Dispatch Ride
                </button>
              ` : `
                <span style="font-size:12px;color:var(--success);font-weight:700;">Auto-Synced</span>
              `}
            </td>
          </tr>
        `;
      }).join('');
    }


function adjustAdminCapacity(shelterId, field, delta) {
      const s = APP_STATE.shelters.find(item => item.id === shelterId);
      if (!s) return;
      s[field] = Math.max(0, s[field] + delta);
      renderAdminMatrix();
      recomputeSpatialShelters();
      showToast(`Live Synced ${s.name}: ${field} set to ${s[field]}.`);
    }


function syncAdminData() {
      renderAdminMatrix();
      recomputeSpatialShelters();
      showToast("Online Active Sync complete across all nearby and farther havens.");
    }

