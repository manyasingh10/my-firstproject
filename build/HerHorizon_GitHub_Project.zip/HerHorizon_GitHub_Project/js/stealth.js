window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && document.getElementById('haven-persona').style.display === 'flex') {
        triggerScrub();
      }
    });


function triggerScrub() {
      if (APP_STATE.isSirenOn) toggleSirenSound();
      stopVisualStrobe();
      if (APP_STATE.simInterval) clearInterval(APP_STATE.simInterval);

      if (APP_STATE.gpsWatchId !== null) {
        navigator.geolocation.clearWatch(APP_STATE.gpsWatchId);
        APP_STATE.gpsWatchId = null;
      }

      APP_STATE.calculatorVal = '0';
      APP_STATE.keySequence = '';
      document.getElementById('calcHistory').innerHTML = '&nbsp;';
      updateCalcDisplay();

      document.title = "QuickCalc Utility";
      document.getElementById('haven-persona').style.display = 'none';
      document.getElementById('calculator-persona').style.display = 'flex';
    }


function openPasscodeModal() {
      document.getElementById('customCodeInput').value = APP_STATE.stealthPasscode;
      document.getElementById('passcodeModal').style.display = 'flex';
    }


function closePasscodeModal() {
      document.getElementById('passcodeModal').style.display = 'none';
    }


function saveCustomPasscode() {
      const val = document.getElementById('customCodeInput').value.trim();
      if (!val) {
        showToast("Passcode cannot be empty.");
        return;
      }
      APP_STATE.stealthPasscode = val;
      localStorage.setItem('herhorizon_stealth_code', val);
      document.getElementById('lblPasscodeDisplay').innerText = val;
      document.getElementById('lblToolPasscode').innerText = val;
      document.getElementById('calcHelpCode').innerText = val;
      closePasscodeModal();
      showToast("Stealth Passcode successfully updated!");
    }

