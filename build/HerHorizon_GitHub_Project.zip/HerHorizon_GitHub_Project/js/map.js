function initLeafletMap() {
      const mapDiv = document.getElementById('realMap');
      if (!mapDiv) return;

      if (!APP_STATE.map) {
        APP_STATE.map = L.map('realMap', { zoomControl: true, attributionControl: false }).setView([APP_STATE.coords.lat, APP_STATE.coords.lng], 15);

        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
          maxZoom: 19
        }).addTo(APP_STATE.map);

        const userDivIcon = L.divIcon({
          className: 'user-corridor-marker',
          html: `
            <div style="position:relative;width:28px;height:28px;">
              <div style="position:absolute;top:0;left:0;width:28px;height:28px;background:rgba(123,44,191,0.3);border-radius:50%;animation:pulseRing 1.8s infinite;"></div>
              <div style="position:absolute;top:5px;left:5px;width:18px;height:18px;background:#7b2cbf;border:3px solid #ffffff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,0.4);"></div>
            </div>
          `,
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        });

        APP_STATE.userMarker = L.marker([APP_STATE.coords.lat, APP_STATE.coords.lng], { icon: userDivIcon })
          .addTo(APP_STATE.map)
          .bindPopup("<strong>Live Verified GPS Node</strong><br>Start Location (Auto-detected)");

        APP_STATE.accuracyCircle = L.circle([APP_STATE.coords.lat, APP_STATE.coords.lng], {
          radius: APP_STATE.coords.acc,
          color: '#0284c7',
          fillColor: '#38bdf8',
          fillOpacity: 0.15,
          weight: 1.5
        }).addTo(APP_STATE.map);

        APP_STATE.shelterMarkersGroup = L.layerGroup().addTo(APP_STATE.map);
        APP_STATE.guardMarkersGroup = L.layerGroup().addTo(APP_STATE.map);

        recomputeCorridorPolylines();
        recomputeSpatialShelters();
      }

      setTimeout(() => {
        if (APP_STATE.map) APP_STATE.map.invalidateSize();
      }, 150);
    }


function updateMapPositions(lat, lng, acc) {
      if (!APP_STATE.map || !APP_STATE.userMarker) return;
      const newLatLng = [lat, lng];
      APP_STATE.userMarker.setLatLng(newLatLng);
      APP_STATE.accuracyCircle.setLatLng(newLatLng);
      APP_STATE.accuracyCircle.setRadius(acc);
      recomputeCorridorPolylines();
    }


function centerOnUser() {
      if (APP_STATE.map) {
        APP_STATE.map.invalidateSize();
        APP_STATE.map.setView([APP_STATE.coords.lat, APP_STATE.coords.lng], 15, { animate: true });
      }
    }


function recomputeCorridorPolylines() {
      if (!APP_STATE.map) return;
      const uLat = APP_STATE.coords.lat;
      const uLng = APP_STATE.coords.lng;

      const safePoints = [
        [uLat, uLng],
        [uLat - 0.0021, uLng - 0.0015],
        [uLat - 0.0067, uLng - 0.0029],
        [uLat - 0.0094, uLng - 0.0034]
      ];

      const directPoints = [
        [uLat, uLng],
        [uLat - 0.0047, uLng - 0.0008],
        [uLat - 0.0094, uLng - 0.0034]
      ];

      if (APP_STATE.corridorLayers.safe) APP_STATE.map.removeLayer(APP_STATE.corridorLayers.safe);
      if (APP_STATE.corridorLayers.direct) APP_STATE.map.removeLayer(APP_STATE.corridorLayers.direct);

      APP_STATE.corridorLayers.safe = L.polyline(safePoints, {
        color: '#7b2cbf',
        weight: 6,
        opacity: 0.9,
        lineCap: 'round'
      });

      APP_STATE.corridorLayers.direct = L.polyline(directPoints, {
        color: '#f59e0b',
        weight: 4,
        dashArray: '6, 8',
        opacity: 0.8
      });

      if (APP_STATE.selectedCorridor === 'safe') {
        APP_STATE.corridorLayers.safe.addTo(APP_STATE.map);
      } else {
        APP_STATE.corridorLayers.direct.addTo(APP_STATE.map);
      }
    }


function calculateHaversine(lat1, lon1, lat2, lon2) {
      const R = 6371;
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLon = (lon2 - lon1) * Math.PI / 180;
      const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    }


function recomputeSpatialShelters() {
      const uLat = APP_STATE.coords.lat;
      const uLng = APP_STATE.coords.lng;

      if (APP_STATE.map && APP_STATE.shelterMarkersGroup) {
        APP_STATE.shelterMarkersGroup.clearLayers();
        APP_STATE.guardMarkersGroup.clearLayers();
      }

      const shelterIcon = L.divIcon({
        html: `<div style="background:#7b2cbf;color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.3);font-size:14px;">🏠</div>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14]
      });

      const guardIcon = L.divIcon({
        html: `<div style="background:#0284c7;color:#fff;width:24px;height:24px;border-radius:6px;display:flex;align-items:center;justify-content:center;border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,0.3);font-size:12px;">👮</div>`,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const selectEl = document.getElementById('txDestinationSelect');
      if (selectEl) selectEl.innerHTML = '';

      APP_STATE.shelters.forEach(s => {
        const sLat = uLat + s.dLat;
        const sLng = uLng + s.dLng;
        const distKm = calculateHaversine(uLat, uLng, sLat, sLng).toFixed(1);
        s.computedDist = `${distKm} km`;

        if (APP_STATE.map && APP_STATE.shelterMarkersGroup) {
          L.marker([sLat, sLng], { icon: shelterIcon })
            .addTo(APP_STATE.shelterMarkersGroup)
            .bindPopup(`
              <div style="font-family:sans-serif;padding:4px;">
                <strong style="color:#241442;">${s.name}</strong><br>
                <span style="font-size:12px;color:#646174;">${s.beds > 0 ? s.beds + ' beds available' : 'At Capacity'}</span><br>
                <div style="display:flex;gap:4px;margin-top:6px;">
                  <button onclick="quickTransitToShelter('${s.name}')" style="background:#241442;color:#fff;border:none;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:700;">Safe Ride</button>
                  <button onclick="startWalkToShelter(${s.id})" style="background:#7b2cbf;color:#fff;border:none;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:700;">Walk Route</button>
                </div>
              </div>
            `);
        }

        if (selectEl) {
          const opt = document.createElement('option');
          opt.value = s.name;
          opt.innerText = `${s.name} (${s.area} • ${distKm} km)${s.isFarther ? ' [Farther Haven]' : ''}`;
          selectEl.appendChild(opt);
        }
      });

      if (APP_STATE.map && APP_STATE.guardMarkersGroup) {
        const guardCoords = [
          [uLat - 0.0017, uLng + 0.0032],
          [uLat - 0.0051, uLng + 0.0004]
        ];
        guardCoords.forEach(c => {
          L.marker(c, { icon: guardIcon })
            .addTo(APP_STATE.guardMarkersGroup)
            .bindPopup("<strong>Active Police/Community Guard Kiosk</strong><br>24/7 Monitored Safe Node");
        });
      }

      renderShelterCards();
      updateBedCountsSummary();
    }


function selectCorridor(type) {
      APP_STATE.selectedCorridor = type;
      const safeCard = document.getElementById('cardCorridorSafe');
      const directCard = document.getElementById('cardCorridorDirect');

      if (type === 'safe') {
        safeCard.classList.add('active');
        directCard.classList.remove('active');
        if (APP_STATE.map && !APP_STATE.map.hasLayer(APP_STATE.corridorLayers.safe)) APP_STATE.map.addLayer(APP_STATE.corridorLayers.safe);
        if (APP_STATE.map && APP_STATE.map.hasLayer(APP_STATE.corridorLayers.direct)) APP_STATE.map.removeLayer(APP_STATE.corridorLayers.direct);
        showToast("Safe Corridor Engaged (98% Safety Score)");
      } else {
        directCard.classList.add('active');
        safeCard.classList.remove('active');
        if (APP_STATE.map && !APP_STATE.map.hasLayer(APP_STATE.corridorLayers.direct)) APP_STATE.map.addLayer(APP_STATE.corridorLayers.direct);
        if (APP_STATE.map && APP_STATE.map.hasLayer(APP_STATE.corridorLayers.safe)) APP_STATE.map.removeLayer(APP_STATE.corridorLayers.safe);
        showToast("Caution: Direct shortcut traverses unlit alleys.");
      }
    }


function toggleLayer(layerName) {
      if (!APP_STATE.map) return;
      if (layerName === 'shelters') {
        const checked = document.getElementById('chkShelters').checked;
        checked ? APP_STATE.map.addLayer(APP_STATE.shelterMarkersGroup) : APP_STATE.map.removeLayer(APP_STATE.shelterMarkersGroup);
      } else if (layerName === 'guards') {
        const checked = document.getElementById('chkGuards').checked;
        checked ? APP_STATE.map.addLayer(APP_STATE.guardMarkersGroup) : APP_STATE.map.removeLayer(APP_STATE.guardMarkersGroup);
      } else if (layerName === 'corridors') {
        const checked = document.getElementById('chkCorridors').checked;
        if (checked) {
          APP_STATE.selectedCorridor === 'safe' ? APP_STATE.map.addLayer(APP_STATE.corridorLayers.safe) : APP_STATE.map.addLayer(APP_STATE.corridorLayers.direct);
        } else {
          APP_STATE.map.removeLayer(APP_STATE.corridorLayers.safe);
          APP_STATE.map.removeLayer(APP_STATE.corridorLayers.direct);
        }
      } else if (layerName === 'radius') {
        const checked = document.getElementById('chkRadius').checked;
        checked ? APP_STATE.map.addLayer(APP_STATE.accuracyCircle) : APP_STATE.map.removeLayer(APP_STATE.accuracyCircle);
      }
    }

