function showPortalTab(viewId, btnEl) {
      document.getElementById('view-shelters').style.display = 'none';
      document.getElementById('view-map').style.display = 'none';
      document.getElementById('view-transit').style.display = 'none';
      document.getElementById('view-support').style.display = 'none';
      document.getElementById('view-admin').style.display = 'none';
      document.getElementById('view-tools').style.display = 'none';
      document.getElementById('view-guardians').style.display = 'none';

      document.querySelectorAll('.nav-tab-btn').forEach(b => b.classList.remove('active'));

      const target = document.getElementById(viewId);
      if (viewId === 'view-map') {
        target.style.display = 'flex';
        initLeafletMap();
        setTimeout(() => {
          if (APP_STATE.map) {
            APP_STATE.map.invalidateSize();
            centerOnUser();
          }
        }, 120);
      } else {
        target.style.display = 'block';
      }

      if (btnEl) btnEl.classList.add('active');
    }


function broadcastCurrentCoordsToGuardians() {
      const currentPos = APP_STATE.userMarker ? APP_STATE.userMarker.getLatLng() : APP_STATE.coords;
      const coordStr = `${currentPos.lat.toFixed(6)}, ${currentPos.lng.toFixed(6)}`;
      showToast(`Exact GPS Coordinates [${coordStr}] transmitted to Maya Lin & Elena Vance.`);
    }


function showToast(msg) {
      const toast = document.getElementById('portalToast');
      toast.innerText = msg;
      toast.classList.add('shown');
      setTimeout(() => toast.classList.remove('shown'), 3000);
    }

