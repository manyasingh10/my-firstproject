function toggleShelterScope(scope, btn) {
      APP_STATE.currentShelterScope = scope;
      document.getElementById('chipAvailableShelters').classList.remove('active');
      document.getElementById('chipAllHavens').classList.remove('active');
      btn.classList.add('active');
      renderShelterCards();
    }


function filterShelterTag(tag, btn) {
      document.querySelectorAll('.shelter-filters .filter-chip').forEach(c => {
        if (c.id !== 'chipAvailableShelters' && c.id !== 'chipAllHavens') c.classList.remove('active');
      });
      btn.classList.add('active');
      APP_STATE.currentFilterTag = tag;
      renderShelterCards();
    }


function renderShelterCards() {
      const container = document.getElementById('shelterListingGrid');
      if (!container) return;

      let list = APP_STATE.shelters;

      if (APP_STATE.currentShelterScope === 'available') {
        list = list.filter(s => s.beds > 0 && !s.isFarther);
      }

      if (APP_STATE.currentFilterTag !== 'all') {
        list = list.filter(s => s.tags.includes(APP_STATE.currentFilterTag));
      }

      container.innerHTML = list.map(s => {
        const isFull = s.beds === 0;
        return `
        <div class="shelter-entry-card ${s.isFarther ? 'farther-shelter' : ''}">
          <div>
            <div class="sec-badge-row">
              <span class="badge-bed ${isFull ? 'full' : ''}">
                ${isFull ? 'At Capacity • Auto-Rerouting Active' : s.beds + ' Beds Open Now'}
              </span>
              <span style="font-size:12px;font-weight:700;color:var(--primary);">📍 ${s.computedDist || '1.1 km'} away</span>
            </div>
            <h3 class="shelter-entry-title">${s.name}</h3>
            <div style="font-size:12px;color:var(--text-muted);font-weight:600;margin-bottom:4px;">${s.area} • ${s.address}</div>
            
            <div class="feature-pills" style="margin-top:8px;">
              <span class="badge-sec-tag">🛡️ ${s.secType}</span>
              <span class="pill">Family Units: ${s.familyUnits}</span>
              ${s.isFarther ? '<span class="pill" style="background:#f3e8ff;color:#7e22ce;font-weight:700;">Farther Location</span>' : ''}
              ${s.tags.includes('pets') ? '<span class="pill">🐾 Pets Welcome</span>' : ''}
              ${s.tags.includes('accessible') ? '<span class="pill">♿ Barrier Free</span>' : ''}
            </div>
          </div>

          <div>
            <button class="btn-act primary" style="width:100%;margin-bottom:6px;font-size:12.5px;" onclick="requestBedHold(${s.id})">
              🔒 Hold Bed Token (90 Min)
            </button>
            <div class="shelter-actions-row">
              <button class="btn-act dark" onclick="quickTransitToShelter('${s.name}')">
                🚗 Safe Ride
              </button>
              <button class="btn-act primary" onclick="startWalkToShelter(${s.id})">
                🚶 Walk Safer Route
              </button>
            </div>
          </div>
        </div>
        `;
      }).join('');
    }


function updateBedCountsSummary() {
      const totalBeds = APP_STATE.shelters.reduce((acc, s) => acc + s.beds, 0);
      const totalFamily = APP_STATE.shelters.reduce((acc, s) => acc + s.familyUnits, 0);
      
      const elBeds = document.getElementById('statOpenBeds');
      const elFam = document.getElementById('statFamilyUnits');
      if (elBeds) elBeds.innerText = totalBeds;
      if (elFam) elFam.innerText = totalFamily;
    }


function startWalkToShelter(shelterId) {
      const shelter = APP_STATE.shelters.find(s => s.id === shelterId) || APP_STATE.shelters[0];
      APP_STATE.activeShelterId = shelterId;

      document.getElementById('lblWalkTargetShelter').innerText = `Target: ${shelter.name}`;

      const mapBtn = document.querySelectorAll('.nav-tab-btn')[1];
      showPortalTab('view-map', mapBtn);

      initLeafletMap();
      selectCorridor('safe');
      startContinuousWalkSimulation();
      showToast(`Walking Safer Route to ${shelter.name} active with live escorted simulation.`);
    }


function startContinuousWalkSimulation() {
      if (APP_STATE.simInterval) clearInterval(APP_STATE.simInterval);
      APP_STATE.isSimulating = true;
      APP_STATE.simStep = 0;

      const uLat = APP_STATE.coords.lat;
      const uLng = APP_STATE.coords.lng;
      const path = [
        [uLat, uLng],
        [uLat - 0.0012, uLng - 0.0008],
        [uLat - 0.0024, uLng - 0.0016],
        [uLat - 0.0048, uLng - 0.0022],
        [uLat - 0.0072, uLng - 0.0030],
        [uLat - 0.0094, uLng - 0.0034]
      ];

      const btn = document.getElementById('btnSimulate');
      btn.innerText = "⏸ Walking Escort Simulation Running...";

      APP_STATE.simInterval = setInterval(() => {
        APP_STATE.simStep++;
        if (APP_STATE.simStep >= path.length) {
          clearInterval(APP_STATE.simInterval);
          APP_STATE.isSimulating = false;
          btn.innerText = "▶ Restart Walking Escort Simulation";
          showToast("Arrived safely at Shelter Perimeter Gate!");
          return;
        }
        const pt = path[APP_STATE.simStep];
        if (APP_STATE.userMarker) APP_STATE.userMarker.setLatLng(pt);
        if (APP_STATE.accuracyCircle) APP_STATE.accuracyCircle.setLatLng(pt);
        if (APP_STATE.map) APP_STATE.map.panTo(pt);
      }, 1900);
    }


function toggleMovementSimulation() {
      const btn = document.getElementById('btnSimulate');
      if (APP_STATE.isSimulating) {
        clearInterval(APP_STATE.simInterval);
        APP_STATE.isSimulating = false;
        btn.innerText = "▶ Resume Walking Escort Simulation";
        showToast("Escort simulation paused.");
      } else {
        startContinuousWalkSimulation();
      }
    }

