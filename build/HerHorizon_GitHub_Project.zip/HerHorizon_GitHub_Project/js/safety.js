function toggleSirenSound() {
      if (APP_STATE.isSirenOn) {
        if (APP_STATE.sirenOsc) APP_STATE.sirenOsc.stop();
        APP_STATE.isSirenOn = false;
        showToast("Audio Siren Deactivated");
      } else {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        APP_STATE.audioContext = new AudioContext();

        const osc = APP_STATE.audioContext.createOscillator();
        const gain = APP_STATE.audioContext.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800, APP_STATE.audioContext.currentTime);
        osc.frequency.linearRampToValueAtTime(1350, APP_STATE.audioContext.currentTime + 0.35);
        osc.frequency.linearRampToValueAtTime(800, APP_STATE.audioContext.currentTime + 0.7);

        gain.gain.setValueAtTime(0.35, APP_STATE.audioContext.currentTime);
        osc.connect(gain);
        gain.connect(APP_STATE.audioContext.destination);

        osc.start();
        APP_STATE.sirenOsc = osc;
        APP_STATE.isSirenOn = true;
        showToast("High-Decibel Siren Active!");
      }
    }


function triggerVisualStrobe() {
      document.getElementById('visualStrobe').classList.add('strobe-flashing');
      showToast("Tap screen anywhere to stop strobe beacon");
    }


function stopVisualStrobe() {
      document.getElementById('visualStrobe').classList.remove('strobe-flashing');
    }


function scheduleFakeCall() {
      showToast("Decoy Call scheduled in 3 seconds. Place phone to ear.");
      setTimeout(() => {
        const answered = confirm("📞 INCOMING CALL:\nHome / Advocate Office\n\nPress OK to Answer, Cancel to Dismiss.");
        if (answered && "speechSynthesis" in window) {
          const speech = new SpeechSynthesisUtterance("Hi, I'm right outside by the corner transit point. I have the car ready, come out whenever you're ready.");
          speech.rate = 0.95;
          window.speechSynthesis.speak(speech);
        }
      }, 3000);
    }


function openSOSDialog() {
      document.getElementById('sosModal').style.display = 'flex';
      document.getElementById('sosCoords').innerText = `${APP_STATE.coords.lat.toFixed(5)}, ${APP_STATE.coords.lng.toFixed(5)}`;
      document.getElementById('sosAcc').innerText = `±${APP_STATE.coords.acc} m`;

      if ('getBattery' in navigator) {
        navigator.getBattery().then(b => {
          document.getElementById('sosBattery').innerText = `${Math.round(b.level * 100)}% (${b.charging ? 'Charging' : 'Discharging'})`;
        });
      } else {
        document.getElementById('sosBattery').innerText = '84% (Nominal)';
      }
    }


function closeSOSDialog() {
      document.getElementById('sosModal').style.display = 'none';
    }


function broadcastEmergencyBeacon() {
      closeSOSDialog();
      showToast("🚨 Priority SOS Broadcasted to Police Patrol & Guardians!");
    }

