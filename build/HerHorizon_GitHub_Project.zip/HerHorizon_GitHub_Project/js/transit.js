function quickTransitToShelter(shelterName) {
      const select = document.getElementById('txDestinationSelect');
      if (select) select.value = shelterName;
      const transitTabBtn = document.querySelectorAll('.nav-tab-btn')[2];
      showPortalTab('view-transit', transitTabBtn);
      showToast(`Safe transit configured for ${shelterName}.`);
    }


function onDestinationChanged() {
      document.getElementById('driverDetailsCard').style.display = 'none';
    }


function dispatchSafeTransit() {
      const dest = document.getElementById('txDestinationSelect').value;
      const card = document.getElementById('driverDetailsCard');
      const singlePin = Math.floor(1000 + Math.random() * 9000);

      document.getElementById('unifiedPIN').innerText = singlePin;
      document.getElementById('driverSpokenPin').innerText = singlePin;
      card.style.display = 'block';

      showToast(`Verified municipal transit dispatched to ${dest}! Driver & Officer verified.`);
      card.scrollIntoView({ behavior: 'smooth' });
    }


function dispatchFartherShelterRide(shelterName) {
      const transitBtn = document.querySelectorAll('.nav-tab-btn')[2];
      showPortalTab('view-transit', transitBtn);
      const select = document.getElementById('txDestinationSelect');
      if (select) select.value = shelterName;
      dispatchSafeTransit();
      showToast(`Safe Ride to Farther Shelter (${shelterName}) confirmed with zero-cost voucher.`);
    }


function requestBedHold(shelterId) {
      const shelter = APP_STATE.shelters.find(s => s.id === shelterId);
      if (!shelter) return;

      const randToken = '#HOLD-' + Math.floor(1000 + Math.random() * 9000);
      document.getElementById('holdTokenCode').innerText = randToken;
      document.getElementById('holdModalDesc').innerText = `Confidential bed reserved at ${shelter.name} (${shelter.area}) for 90 minutes. Intake desk is notified.`;
      
      document.getElementById('holdModal').style.display = 'flex';
    }


function closeHoldModal(proceedToTransit) {
      document.getElementById('holdModal').style.display = 'none';
      if (proceedToTransit) {
        const transitBtn = document.querySelectorAll('.nav-tab-btn')[2];
        showPortalTab('view-transit', transitBtn);
        showToast("Transit coordinates linked to bed reservation.");
      }
    }


function openTransitPassModal() {
      document.getElementById('transitPassModal').style.display = 'flex';
    }


function closeTransitPassModal() {
      document.getElementById('transitPassModal').style.display = 'none';
    }


function claimTransitPassAction() {
      closeTransitPassModal();
      const transitBtn = document.querySelectorAll('.nav-tab-btn')[2];
      showPortalTab('view-transit', transitBtn);
      showToast("Free Transit Voucher applied to current ride!");
    }

