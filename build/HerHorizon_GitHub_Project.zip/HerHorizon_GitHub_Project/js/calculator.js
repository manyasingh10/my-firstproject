function updateCalcDisplay() {
      document.getElementById('calcDisplay').innerText = APP_STATE.calculatorVal;
    }


function calcInput(digit) {
      if (APP_STATE.calculatorVal === '0' && digit !== '.') {
        APP_STATE.calculatorVal = digit;
      } else {
        if (digit === '.' && APP_STATE.calculatorVal.includes('.')) return;
        APP_STATE.calculatorVal += digit;
      }
      APP_STATE.keySequence += digit;
      updateCalcDisplay();
      checkStegCode();
    }


function calcAction(op) {
      APP_STATE.keySequence += op;

      if (op === 'C') {
        APP_STATE.calculatorVal = '0';
        document.getElementById('calcHistory').innerHTML = '&nbsp;';
      } else if (op === '=') {
        try {
          const sanitized = APP_STATE.calculatorVal.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
          document.getElementById('calcHistory').innerText = APP_STATE.calculatorVal + ' =';
          APP_STATE.calculatorVal = String(Function(`'use strict'; return (${sanitized})`)());
        } catch {
          APP_STATE.calculatorVal = 'Error';
        }
      } else if (['+', '-', '*', '/'].includes(op)) {
        const symbol = op === '*' ? '×' : (op === '/' ? '÷' : (op === '-' ? '−' : '+'));
        APP_STATE.calculatorVal += ` ${symbol} `;
      } else if (op === '+/-') {
        if (APP_STATE.calculatorVal.startsWith('-')) {
          APP_STATE.calculatorVal = APP_STATE.calculatorVal.substring(1);
        } else {
          APP_STATE.calculatorVal = '-' + APP_STATE.calculatorVal;
        }
      } else if (op === '%') {
        APP_STATE.calculatorVal = String(parseFloat(APP_STATE.calculatorVal) / 100);
      }

      updateCalcDisplay();
      checkStegCode();
    }


function checkStegCode() {
      const s = APP_STATE.keySequence;
      const custom = APP_STATE.stealthPasscode;
      if (s.includes(custom) || s.includes("98.6+=") || s.includes("999=") || s.endsWith("911=")) {
        APP_STATE.keySequence = '';
        unlockSafeRoute();
      }
      if (APP_STATE.keySequence.length > 30) {
        APP_STATE.keySequence = APP_STATE.keySequence.slice(-12);
      }
    }


function unlockSafeRoute() {
      document.title = "HerHorizon — SafeRoute";
      document.getElementById('calculator-persona').style.display = 'none';
      
      const haven = document.getElementById('haven-persona');
      haven.style.display = 'flex';
      
      document.getElementById('lblPasscodeDisplay').innerText = APP_STATE.stealthPasscode;
      document.getElementById('lblToolPasscode').innerText = APP_STATE.stealthPasscode;

      renderAdminMatrix();
      updateBedCountsSummary();
      startActiveGPSWatcher();
      showToast("Live Active GPS SafeRoute Engaged");
    }

