function startActiveGPSWatcher() {
      if (!("geolocation" in navigator)) {
        updateUIWithCoordinates(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc, false);
        return;
      }

      APP_STATE.gpsWatchId = navigator.geolocation.watchPosition(
        (pos) => {
          APP_STATE.hasLiveGPS = true;
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const acc = Math.round(pos.coords.accuracy || 15);

          APP_STATE.coords = { lat, lng, acc };
          updateUIWithCoordinates(lat, lng, acc, true);
          updateMapPositions(lat, lng, acc);
          recomputeSpatialShelters();
        },
        (err) => {
          updateUIWithCoordinates(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc, false);
          recomputeSpatialShelters();
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 2000 }
      );
    }


function forceGPSRefresh() {
      showToast("Polling immediate GPS fix from hardware...");
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            APP_STATE.hasLiveGPS = true;
            APP_STATE.coords = {
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
              acc: Math.round(pos.coords.accuracy || 15)
            };
            updateUIWithCoordinates(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc, true);
            updateMapPositions(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc);
            recomputeSpatialShelters();
            centerOnUser();
            showToast("Satellite GPS Refreshed");
          },
          () => showToast("Hardware signal unavailable. Retaining current node.")
        );
      }
    }


function updateUIWithCoordinates(lat, lng, acc, isLive) {
      document.getElementById('lblLat').innerText = lat.toFixed(6);
      document.getElementById('lblLng').innerText = lng.toFixed(6);
      document.getElementById('lblAcc').innerText = `±${acc} meters`;
      
      const badge = document.getElementById('gpsModeBadge');
      if (isLive) {
        badge.innerHTML = `<span style="display:inline-block;width:6px;height:6px;background:#10b981;border-radius:50%;"></span> Active Satellite Lock`;
        badge.style.color = "#047857";
        badge.style.background = "#d1fae5";
        document.getElementById('topBarGPSStatus').innerText = `Live GPS Stream (±${acc}m)`;
      }

      const coordStr = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      document.getElementById('txPickupPoint').value = `${coordStr} (Auto-detected Current Location)`;
      document.getElementById('guardianPingPreview').innerText = `"Safe on Corridor. Coordinates: ${coordStr}"`;
      document.getElementById('sosCoords').innerText = coordStr;
      document.getElementById('sosAcc').innerText = `±${acc} m`;
    }


function loadSampleKalyanCoords() {
      APP_STATE.coords = { lat: 19.250904, lng: 73.142782, acc: 12 };
      updateUIWithCoordinates(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc, true);
      updateMapPositions(APP_STATE.coords.lat, APP_STATE.coords.lng, APP_STATE.coords.acc);
      recomputeSpatialShelters();
      centerOnUser();
      showToast("Loaded Sample City Mesh");
    }

