function callCustomerLine802() {
      showToast("Connecting directly to Customer Line #802 Trauma Counselor...");
      setTimeout(() => {
        alert("📞 Connected to Customer Line #802\n\nTrauma Counselor on Line: Specialist Maya\nStatus: Secure, zero-log priority channel.\n\nYou are in a safe space. Speak freely or type via chat.");
      }, 500);
    }


function bookFreeRideFromSupport() {
      const transitBtn = document.querySelectorAll('.nav-tab-btn')[2];
      showPortalTab('view-transit', transitBtn);
      showToast("Booking Free Safe Ride with subsidized transit voucher.");
    }


function submitChatMessage() {
      const input = document.getElementById('supportChatInput');
      const text = input.value.trim();
      if (!text) return;

      appendChatMessage(text, 'user');
      input.value = '';

      setTimeout(() => {
        let reply = "We hear you, and you are not alone. Our trauma specialist has logged your request anonymously. How can we best assist your next step?";
        const low = text.toLowerCase();
        if (low.includes('bed') || low.includes('shelter')) {
          reply = "I can immediately lock an exclusive 90-minute bed hold for you at our highest-security shelter. Would you like me to reserve it right now?";
        } else if (low.includes('transit') || low.includes('ride') || low.includes('pass')) {
          reply = "Your City Commute Transit Pass is available for zero-cost immediate travel. Would you like a silent pickup dispatched to your current coordinates?";
        } else if (low.includes('counsel') || low.includes('trauma') || low.includes('802')) {
          reply = "A certified trauma-informed counselor is active on Customer Line #802. Would you like an instant secure voice connection?";
        }
        appendChatMessage(reply, 'bot');
      }, 700);
    }


function sendQuickChatMessage(msg) {
      appendChatMessage(msg, 'user');
      setTimeout(() => {
        if (msg.includes('bed')) {
          requestBedHold(1);
          appendChatMessage("I have initiated a 90-Minute Bed Hold at Emergency Refugee Sanctuary. Check the confirmation token on your screen.", "bot");
        } else if (msg.includes('Transit Voucher')) {
          openTransitPassModal();
          appendChatMessage("Opening your complimentary City Commute Pass modal now.", "bot");
        } else if (msg.includes('802')) {
          callCustomerLine802();
        } else {
          appendChatMessage("Trauma support priority is active. We are standing by to guide your safety discreetly.", "bot");
        }
      }, 600);
    }


function appendChatMessage(msg, sender) {
      const container = document.getElementById('chatMsgContainer');
      const div = document.createElement('div');
      div.className = `chat-msg ${sender}`;
      div.innerText = msg;
      container.appendChild(div);
      container.scrollTop = container.scrollHeight;
    }


function resetChat() {
      const container = document.getElementById('chatMsgContainer');
      container.innerHTML = `
        <div class="chat-msg bot">
          Hello. You are connected directly to confidential support. You are in a safe, encrypted space. How can we assist your safety right now?
        </div>
      `;
      showToast("Chat transcript purged.");
    }


function sendSilentBeacon() {
      showToast("Silent Beacon active. Coordinates & battery quietly broadcasted.");
    }


function callGuardian(name, number) {
      showToast(`Initiating immediate call to ${name} (${number})...`);
      setTimeout(() => {
        alert(`📞 Immediate Call Connected:\n\nGuardian: ${name}\nNumber: ${number}\nStatus: Live audio bridge active.`);
      }, 400);
    }

